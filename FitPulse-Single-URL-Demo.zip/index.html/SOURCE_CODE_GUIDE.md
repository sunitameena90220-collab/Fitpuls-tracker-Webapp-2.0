# 🏋️ FitPulse - Complete Source Code Documentation

## 📁 Project Structure

```
FitPulse/
├── server.js              # Main backend server (Express + SQLite)
├── package.json           # Dependencies & scripts
├── start.bat             # Windows launcher
├── start.sh              # Mac/Linux launcher
├── README.txt            # User guide (Hindi)
└── public/               # Frontend files (Expo web build)
    ├── index.html        # Main HTML entry point
    ├── favicon.ico       # App icon
    ├── metadata.json     # App metadata
    ├── assets/           # Images, fonts, etc.
    └── _expo/            # Compiled Expo React app
        └── static/
            ├── css/      # Stylesheets
            └── js/       # JavaScript bundles
```

---

## 🔧 Technology Stack

### Backend
- **Node.js** - Server runtime
- **Express.js** - Web framework
- **better-sqlite3** - SQLite database driver
- **SQLite** - Embedded database (no installation needed)

### Frontend
- **Expo** - React Native framework (web export)
- **React Native Web** - Renders React Native to HTML/CSS
- **React** - UI library

---

## 💾 Database Schema

### Tables:

#### `users`
```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  fitness_goal TEXT DEFAULT 'general_fitness',
  age INTEGER,
  weight REAL,
  height REAL,
  activity_level TEXT DEFAULT 'moderately_active',
  avatar_url TEXT,
  bio TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
```

#### `workouts`
```sql
CREATE TABLE workouts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  workout_name TEXT NOT NULL,
  category TEXT DEFAULT 'strength',
  duration INTEGER DEFAULT 0,
  calories_burned INTEGER DEFAULT 0,
  exercises TEXT DEFAULT '[]',
  notes TEXT,
  completed_at TEXT DEFAULT (datetime('now')),
  created_at TEXT DEFAULT (datetime('now'))
);
```

#### `goals`
```sql
CREATE TABLE goals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  target_value REAL DEFAULT 0,
  current_value REAL DEFAULT 0,
  unit TEXT DEFAULT '',
  category TEXT DEFAULT 'fitness',
  deadline TEXT,
  completed INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);
```

#### `progress`
```sql
CREATE TABLE progress (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  workouts_completed INTEGER DEFAULT 0,
  calories_burned INTEGER DEFAULT 0,
  minutes_active INTEGER DEFAULT 0,
  weight REAL,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
```

---

## 🔐 Authentication System

### Password Hashing
```javascript
function hashPassword(password) {
  return crypto.createHash("sha256")
    .update(password + "fitpulse_salt")
    .digest("hex");
}
```

### Token Generation
```javascript
function generateToken(userId) {
  return Buffer.from(
    `${userId}:${Date.now()}:${crypto.randomBytes(16).toString("hex")}`
  ).toString("base64url");
}
```

### Security Notes:
- Passwords are hashed with SHA-256 + salt
- Tokens include user ID, timestamp, and random bytes
- NOT production-ready (use bcrypt + JWT in real apps)

---

## 🌐 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create new account |
| POST | `/api/auth/login` | Login user |
| POST | `/api/auth/forgot-password` | Password reset (mock) |

### User Management
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users/profile?userId={id}` | Get user profile |
| PUT | `/api/users/profile` | Update profile |
| PUT | `/api/users/change-email` | Change email |
| PUT | `/api/users/change-password` | Change password |
| GET | `/api/users/stats?userId={id}` | Get workout stats |

### Workouts
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/workouts?userId={id}` | Get all workouts |
| POST | `/api/workouts` | Create workout |
| GET | `/api/workouts/plans` | Get workout plans |
| GET | `/api/exercises` | Get exercise library |

### Progress Tracking
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/progress/summary?userId={id}&days={n}` | Get progress data |
| POST | `/api/progress` | Log daily progress |

### Goals
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/goals?userId={id}` | Get all goals |
| POST | `/api/goals` | Create new goal |
| PUT | `/api/goals/:id` | Update goal progress |
| DELETE | `/api/goals/:id` | Delete goal |

---

## 🚀 How to Run

### Requirements:
- Node.js v18 or higher

### Windows:
```batch
# Double-click start.bat
# OR manually:
npm install
node server.js
```

### Mac/Linux:
```bash
chmod +x start.sh
./start.sh
# OR manually:
npm install
node server.js
```

### Browser:
Open `http://localhost:3000`

---

## 📝 Code Walkthrough

### server.js Structure:

1. **Database Setup** (Lines 15-72)
   - Creates SQLite database
   - Defines schema
   - Auto-creates tables on startup

2. **Auth Helpers** (Lines 74-89)
   - Password hashing/verification
   - Token generation/parsing

3. **Middleware** (Lines 91-102)
   - JSON body parser
   - Static file serving
   - CORS headers

4. **Auth Routes** (Lines 104-144)
   - Register, Login, Forgot Password

5. **User Routes** (Lines 146-212)
   - Profile management
   - Email/password changes
   - Stats calculation

6. **Workout Routes** (Lines 214-282)
   - CRUD operations
   - Exercise library (hardcoded)
   - Workout plans (hardcoded)

7. **Progress Routes** (Lines 310-333)
   - Daily tracking
   - Charts data

8. **Goals Routes** (Lines 335-363)
   - Goal management
   - Progress updates

9. **Demo Data Seeder** (Lines 374-403)
   - Creates demo account
   - Populates sample data

10. **Server Start** (Lines 405-415)
    - Starts Express server
    - Runs demo seeder
    - Displays startup message

---

## 📦 Data Flow Example

### User Login Flow:
```
1. Frontend → POST /api/auth/login
   Body: { email, password }

2. Server:
   - Find user by email
   - Verify password hash
   - Generate token
   - Return user data + token

3. Frontend:
   - Store token
   - Navigate to dashboard
   - Use token for future requests
```

### Fetching Stats Flow:
```
1. Frontend → GET /api/users/stats?userId=1

2. Server:
   - Query workouts table
   - Calculate totals (calories, minutes)
   - Calculate weekly stats
   - Calculate BMI
   - Count streak
   - Return aggregated data

3. Frontend:
   - Display stats on dashboard
```

---

## 🎨 Frontend Architecture

The frontend is a **compiled Expo web bundle**. Source code is in:
- `/public/_expo/static/js/web/entry-*.js` (minified React bundle)

To **modify the frontend**, you'd need:
1. Original Expo project source code
2. Edit React Native components
3. Run `expo export:web` to rebuild

**Current bundle is production-ready** but not editable without source.

---

## 🔄 Customization Guide

### Adding New Exercise:
```javascript
// In server.js, EXERCISES array (line 269)
{
  id: 16,
  name: "Mountain Climbers",
  category: "cardio",
  muscleGroup: "Core",
  equipment: "None",
  difficulty: "Intermediate",
  sets: 3,
  reps: "30 sec",
  caloriesPerMin: 11
}
```

### Adding New Workout Plan:
```javascript
// In server.js, PLANS array (line 300)
{
  id: 6,
  name: "Morning Routine",
  duration: 3,
  level: "Beginner",
  goal: "general_fitness",
  description: "Quick morning workout",
  exercises: [EXERCISES[0], EXERCISES[4], EXERCISES[10]]
}
```

### Changing Port:
```javascript
// In server.js (line 13)
const PORT = process.env.PORT || 8080; // Change to 8080
```

---

## 🛠️ Deployment Options

### 1. Local Network (Share with friends):
```bash
# Find your IP: ipconfig (Windows) or ifconfig (Mac/Linux)
# Start server
node server.js
# Share: http://YOUR_IP:3000
```

### 2. Heroku:
```bash
# Add Procfile:
echo "web: node server.js" > Procfile
# Deploy:
heroku create fitpulse-app
git push heroku main
```

### 3. Railway.app:
- Upload folder to Railway
- Auto-detects Node.js
- Runs `npm start`

### 4. Render.com:
- Connect GitHub repo
- Build: `npm install`
- Start: `node server.js`

---

## 🔒 Security Improvements (For Production)

⚠️ **Current implementation is for demo/learning only!**

### Critical Changes Needed:
1. **Password Hashing**: Use `bcrypt` instead of SHA-256
2. **JWT Tokens**: Implement proper JWT with expiration
3. **HTTPS**: Force SSL/TLS
4. **Rate Limiting**: Prevent brute force attacks
5. **Input Validation**: Add Joi or similar
6. **SQL Injection**: Already safe (using prepared statements ✅)
7. **Environment Variables**: Store secrets in `.env`
8. **Session Management**: Add proper session handling

---

## 📊 File Sizes

- **Total**: 6.7 MB
- **Frontend bundle**: ~6 MB (Expo web + assets)
- **Backend**: ~25 KB (server.js)
- **Database**: Auto-created on first run

---

## 🐛 Common Issues

### "npm install" fails:
```bash
# Clear cache:
npm cache clean --force
npm install --break-system-packages
```

### Port 3000 already in use:
```bash
# Find and kill process:
# Windows: netstat -ano | findstr :3000
# Mac/Linux: lsof -i :3000
# OR change PORT in server.js
```

### Database locked error:
```bash
# Delete fitpulse.db file
# Server will recreate on next start
```

---

## 📚 Learn More

- **Express.js**: https://expressjs.com
- **SQLite**: https://sqlite.org
- **Expo**: https://docs.expo.dev
- **React Native Web**: https://necolas.github.io/react-native-web

---

## 📄 License

This is a demo/educational project. Use freely for learning.

---

## 👨‍💻 Modifications Welcome!

Ye source code **fully customizable** hai:
- Backend logic badlo (server.js)
- Database schema change karo
- API endpoints add karo
- Deploy anywhere

**Note**: Frontend ko modify karne ke liye original Expo source chahiye.

---

Happy Coding! 🚀

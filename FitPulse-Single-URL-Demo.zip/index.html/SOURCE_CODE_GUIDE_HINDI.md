# 🏋️ FitPulse - Source Code ka Pura Guide (Hindi)

## 📁 Folder Structure

```
FitPulse/
├── server.js              # Backend server (Express + SQLite)
├── package.json           # Dependencies ki list
├── start.bat             # Windows ke liye launcher
├── start.sh              # Mac/Linux ke liye launcher
├── README.txt            # User guide
└── public/               # Frontend files (Expo web)
    ├── index.html        # Main HTML file
    ├── favicon.ico       # App ka icon
    └── _expo/            # React app (compiled)
```

---

## 🔧 Technology Stack (Kya use hua hai)

### Backend (Server side):
- **Node.js** - JavaScript runtime
- **Express.js** - Web server framework
- **SQLite** - Database (koi installation nahi chahiye)
- **better-sqlite3** - Database driver

### Frontend (User interface):
- **Expo** - React Native framework
- **React Native Web** - Mobile code ko web pe run karta hai
- **React** - UI library

---

## 💾 Database Tables

App mein **4 main tables** hain:

### 1. `users` - User ka data
- Email, password, naam
- Height, weight, age
- Fitness goal, activity level

### 2. `workouts` - Workout records
- Workout ka naam, duration
- Calories burned
- Exercises list
- Date/time

### 3. `goals` - Fitness goals
- Goal ka title
- Target value vs current value
- Deadline
- Completed ya nahi

### 4. `progress` - Daily progress
- Date-wise tracking
- Workouts completed
- Calories, minutes
- Weight logging

**Database file**: `fitpulse.db` (auto-create hoti hai)

---

## 🌐 API Endpoints (Backend URLs)

### Authentication (Login/Register):
```
POST /api/auth/register     → Naya account banao
POST /api/auth/login        → Login karo
POST /api/auth/forgot-password → Password reset (demo)
```

### User Profile:
```
GET  /api/users/profile?userId=1   → Profile dekho
PUT  /api/users/profile            → Profile update karo
PUT  /api/users/change-email       → Email badlo
PUT  /api/users/change-password    → Password badlo
GET  /api/users/stats?userId=1     → Stats dekho (BMI, streaks)
```

### Workouts:
```
GET  /api/workouts?userId=1        → Saare workouts
POST /api/workouts                 → Naya workout log karo
GET  /api/workouts/plans           → Workout plans
GET  /api/exercises                → Exercise library
```

### Progress:
```
GET  /api/progress/summary?userId=1&days=7  → Last 7 days ka data
POST /api/progress                          → Aaj ka progress save
```

### Goals:
```
GET    /api/goals?userId=1         → Saare goals
POST   /api/goals                  → Naya goal banao
PUT    /api/goals/:id              → Goal update karo
DELETE /api/goals/:id              → Goal delete karo
```

---

## 🚀 Kaise Chalayein

### Requirements:
- **Node.js** (v18 ya usse bada version)

### Windows mein:
1. `start.bat` file pe double-click karo
2. Ya manually:
   ```
   npm install
   node server.js
   ```
3. Browser mein jao: `http://localhost:3000`

### Mac/Linux mein:
1. Terminal mein:
   ```bash
   chmod +x start.sh
   ./start.sh
   ```
2. Browser mein jao: `http://localhost:3000`

### Demo Account:
- Email: `demo@fitpulse.app`
- Password: `demo123`

---

## 📝 server.js Code Samajhna

**server.js ek hi file mein pura backend hai!** (415 lines)

### Main Parts:

1. **Lines 15-72**: Database Setup
   - SQLite database create hota hai
   - 4 tables banate hain
   - Auto-create on startup

2. **Lines 74-89**: Authentication Functions
   - Password ko hash karna
   - Login token banana
   - Security functions

3. **Lines 91-102**: Middleware
   - JSON parse karna
   - Static files serve karna (HTML, CSS, JS)
   - CORS allow karna

4. **Lines 104-144**: Login/Register Routes
   - `/api/auth/register` - Naya account
   - `/api/auth/login` - Login

5. **Lines 146-212**: User Routes
   - Profile dekho/update karo
   - Email/password change
   - Stats calculate karo

6. **Lines 214-282**: Workout Routes
   - Workouts save/fetch karo
   - Exercise library (15 exercises hardcoded)
   - Workout plans (5 plans hardcoded)

7. **Lines 310-333**: Progress Routes
   - Daily progress track karo
   - Chart data fetch karo

8. **Lines 335-363**: Goals Routes
   - Goals manage karo
   - Progress update karo

9. **Lines 374-403**: Demo Data
   - Demo account banata hai
   - Sample workouts/goals dalata hai

10. **Lines 405-415**: Server Start
    - Port 3000 pe server start
    - Startup message display

---

## 🎨 Frontend Kya Hai

Frontend **compiled React bundle** hai:
- Original source code yahan **nahi hai**
- Sirf production build hai (`/public/_expo/`)
- Minified JavaScript (edit nahi kar sakte directly)

**Frontend edit karne ke liye**:
- Original Expo project chahiye
- React Native code edit karo
- `expo export:web` se rebuild karo

---

## 🔄 Customization Kaise Karein

### 1. Naya Exercise Add Karo:

`server.js` mein line 269 pe `EXERCISES` array hai:

```javascript
{
  id: 16,
  name: "Mountain Climbers",
  category: "cardio",
  muscleGroup: "Core",
  equipment: "None",
  difficulty: "Intermediate",
  sets: 3,
  reps: "30 sec",
  caloriesPerMin: 11
}
```

### 2. Naya Workout Plan Add Karo:

`server.js` mein line 300 pe `PLANS` array hai:

```javascript
{
  id: 6,
  name: "Morning Routine",
  duration: 3,
  level: "Beginner",
  goal: "general_fitness",
  description: "Quick morning workout",
  exercises: [EXERCISES[0], EXERCISES[4]]
}
```

### 3. Port Change Karo:

`server.js` mein line 13:
```javascript
const PORT = process.env.PORT || 8080; // 3000 se 8080 pe change
```

---

## 🌍 Deploy Kaise Karein

### Option 1: Local Network (Apne WiFi pe share)
```bash
# Apna IP nikalo:
# Windows: ipconfig
# Mac/Linux: ifconfig

# Server chalo:
node server.js

# Dusre devices pe share karo:
http://APKA_IP:3000
```

### Option 2: Online Deploy (Free)

**Railway.app**:
1. Railway.app pe account banao
2. "New Project" → Upload folder
3. Auto-detect karega Node.js
4. 5 min mein live!

**Render.com**:
1. GitHub pe code upload karo
2. Render.com connect karo
3. Build: `npm install`
4. Start: `node server.js`

**Heroku**:
```bash
# Procfile banao:
echo "web: node server.js" > Procfile

# Deploy:
heroku create fitpulse-app
git push heroku main
```

---

## 🔒 Security (Production ke liye)

⚠️ **Ye demo project hai, production-ready NAHI hai!**

**Production mein ye changes karo**:

1. **Password Hashing**: `bcrypt` use karo (current: SHA-256)
2. **JWT Tokens**: Proper tokens with expiry
3. **HTTPS**: SSL certificate lagao
4. **Rate Limiting**: Too many requests block karo
5. **Input Validation**: User input ko validate karo
6. **Environment Variables**: Secrets ko `.env` mein rakho

---

## 🐛 Common Problems & Solutions

### 1. "npm install" fail ho raha:
```bash
npm cache clean --force
npm install --break-system-packages
```

### 2. Port 3000 already in use:
**Option A**: Port change karo server.js mein
**Option B**: Process kill karo:
```bash
# Windows:
netstat -ano | findstr :3000
taskkill /PID XXXX /F

# Mac/Linux:
lsof -i :3000
kill -9 XXXX
```

### 3. Database locked error:
```bash
# fitpulse.db file delete karo
# Server restart pe naya ban jayega
```

### 4. Blank screen aa raha:
- Browser console check karo (F12)
- Network tab mein errors dekho
- Server logs dekho terminal mein

---

## 📊 File Sizes

- **Total project**: 6.7 MB
- **Frontend (React bundle)**: ~6 MB
- **Backend (server.js)**: 25 KB
- **Database**: Runtime pe banta hai

---

## 📚 Aur Seekhna Hai?

- **Express.js Tutorial**: https://expressjs.com
- **SQLite Guide**: https://sqlite.org
- **React Tutorial**: https://react.dev
- **Expo Docs**: https://docs.expo.dev

---

## 💡 Modification Ideas

### Easy Changes:
1. Exercise library mein exercises add karo
2. Workout plans add/modify karo
3. Colors/themes change karo (CSS edit)
4. Port number change karo

### Medium Changes:
1. Naye API endpoints banao
2. Database schema extend karo
3. Stats calculations modify karo
4. Email notifications add karo

### Advanced Changes:
1. Frontend ko Expo source se rebuild karo
2. Real authentication (OAuth, JWT)
3. File uploads (profile pictures)
4. Real-time updates (WebSockets)
5. Mobile app build karo (APK/IPA)

---

## 🎯 Important Files Explained

### `server.js` (415 lines):
**Ye file hi pura backend hai!**
- Database setup
- All API routes
- Authentication logic
- Data processing

### `package.json` (14 lines):
Dependencies list:
```json
{
  "dependencies": {
    "better-sqlite3": "^9.4.3",  // Database
    "express": "^4.18.2"         // Web server
  }
}
```

### `public/index.html`:
Frontend ka entry point - React app load karta hai

### `public/_expo/`:
Compiled React app - edit nahi kar sakte directly

---

## ✅ Quick Checklist

Agar tum **backend modify** karna chahte ho:
- [x] `server.js` edit karo
- [x] Restart server: `node server.js`
- [x] Test APIs: Postman ya browser

Agar tum **frontend modify** karna chahte ho:
- [ ] Original Expo source code mangwao
- [ ] React components edit karo
- [ ] `expo export:web` run karo
- [ ] Build ko `public/` mein copy karo

---

## 🚀 Next Steps

1. **Code padho**: Start with `server.js` (comments Hindi mein nahi hain but simple hain)
2. **Experiment karo**: Choti changes try karo
3. **Deploy karo**: Railway/Render pe free hosting
4. **Share karo**: Friends ke saath test karo

---

## 📞 Help Chahiye?

Common resources:
- Node.js errors → Stack Overflow search karo
- SQLite queries → sqlite.org/docs.html
- Expo issues → expo.dev/docs

---

**Yaad rakho**: Ye ek **complete working project** hai. Seedha use kar sakte ho ya customize kar sakte ho!

Happy Coding! 🎉

@echo off
echo.
echo  ======================================
echo   FitPulse - Fitness Tracker App
echo  ======================================
echo.

where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
  echo  ERROR: Node.js is not installed!
  echo  Please download from: https://nodejs.org
  echo  Install it, then run this file again.
  pause
  exit /b
)

echo  Installing dependencies...
call npm install --silent
if %ERRORLEVEL% neq 0 (
  echo  ERROR: Failed to install dependencies.
  pause
  exit /b
)

echo  Starting FitPulse...
echo.
echo  Open Chrome and go to: http://localhost:3000
echo.
start "" "http://localhost:3000"
node server.js
pause

# 🧪 FitPulse API Testing Guide

## 🚀 Quick Start

### Start the Server:
```bash
node server.js
```

Server will run at: `http://localhost:3000`

---

## 🔐 Authentication APIs

### 1. Register New User

**Request:**
```http
POST http://localhost:3000/api/auth/register
Content-Type: application/json

{
  "name": "Rahul Kumar",
  "email": "rahul@example.com",
  "password": "secure123",
  "fitnessGoal": "weight_loss",
  "age": 25,
  "weight": 75,
  "height": 175,
  "activityLevel": "moderately_active"
}
```

**Response:**
```json
{
  "token": "MTo3MTYxMjM0NTY3ODk6YWJjZGVm...",
  "user": {
    "id": 2,
    "name": "Rahul Kumar",
    "email": "rahul@example.com",
    "fitnessGoal": "weight_loss",
    "age": 25,
    "weight": 75,
    "height": 175,
    "activityLevel": "moderately_active",
    "createdAt": "2025-03-21T11:30:00.000Z"
  }
}
```

### 2. Login

**Request:**
```http
POST http://localhost:3000/api/auth/login
Content-Type: application/json

{
  "email": "demo@fitpulse.app",
  "password": "demo123"
}
```

**Response:**
```json
{
  "token": "MTo3MTYxMjM0NTY3ODk6YWJjZGVm...",
  "user": {
    "id": 1,
    "name": "Alex Johnson",
    "email": "demo@fitpulse.app",
    "fitnessGoal": "muscle_gain",
    "age": 28,
    "weight": 75,
    "height": 178
  }
}
```

---

## 👤 User Profile APIs

### 3. Get User Profile

**Request:**
```http
GET http://localhost:3000/api/users/profile?userId=1
```

**Response:**
```json
{
  "id": 1,
  "name": "Alex Johnson",
  "email": "demo@fitpulse.app",
  "fitnessGoal": "muscle_gain",
  "age": 28,
  "weight": 75,
  "height": 178,
  "activityLevel": "moderately_active",
  "avatarUrl": null,
  "bio": null,
  "createdAt": "2025-03-21T10:00:00.000Z"
}
```

### 4. Update Profile

**Request:**
```http
PUT http://localhost:3000/api/users/profile
Content-Type: application/json

{
  "userId": 1,
  "name": "Alex Johnson Updated",
  "age": 29,
  "weight": 73,
  "bio": "Fitness enthusiast, love HIIT workouts!"
}
```

**Response:**
```json
{
  "id": 1,
  "name": "Alex Johnson Updated",
  "email": "demo@fitpulse.app",
  "age": 29,
  "weight": 73,
  "bio": "Fitness enthusiast, love HIIT workouts!"
}
```

### 5. Get User Stats

**Request:**
```http
GET http://localhost:3000/api/users/stats?userId=1
```

**Response:**
```json
{
  "totalWorkouts": 6,
  "totalCaloriesBurned": 1695,
  "totalMinutesActive": 193,
  "weekCaloriesBurned": 310,
  "bmi": 23.6,
  "bmiCategory": "Normal",
  "currentStreak": 3,
  "longestStreak": 3
}
```

### 6. Change Email

**Request:**
```http
PUT http://localhost:3000/api/users/change-email
Content-Type: application/json

{
  "userId": 1,
  "newEmail": "newemail@example.com",
  "password": "demo123"
}
```

**Response:**
```json
{
  "id": 1,
  "email": "newemail@example.com",
  "name": "Alex Johnson"
}
```

### 7. Change Password

**Request:**
```http
PUT http://localhost:3000/api/users/change-password
Content-Type: application/json

{
  "userId": 1,
  "currentPassword": "demo123",
  "newPassword": "newSecure456"
}
```

**Response:**
```json
{
  "message": "Password changed successfully"
}
```

---

## 💪 Workout APIs

### 8. Get All Workouts

**Request:**
```http
GET http://localhost:3000/api/workouts?userId=1
```

**Response:**
```json
[
  {
    "id": 1,
    "userId": 1,
    "workoutName": "Morning HIIT",
    "category": "cardio",
    "duration": 22,
    "caloriesBurned": 310,
    "exercises": "[]",
    "notes": null,
    "completedAt": "2025-03-21T06:00:00.000Z"
  },
  {
    "id": 2,
    "workoutName": "Upper Body Strength",
    "category": "strength",
    "duration": 38,
    "caloriesBurned": 285
  }
]
```

### 9. Log New Workout

**Request:**
```http
POST http://localhost:3000/api/workouts
Content-Type: application/json

{
  "userId": 1,
  "workoutName": "Evening Run",
  "category": "cardio",
  "duration": 30,
  "caloriesBurned": 350,
  "exercises": "[{\"name\":\"Running\",\"duration\":30}]",
  "notes": "5km run at park"
}
```

**Response:**
```json
{
  "id": 7,
  "userId": 1,
  "workoutName": "Evening Run",
  "category": "cardio",
  "duration": 30,
  "caloriesBurned": 350,
  "exercises": "[{\"name\":\"Running\",\"duration\":30}]",
  "notes": "5km run at park",
  "completedAt": "2025-03-21T11:45:00.000Z"
}
```

### 10. Get Exercise Library

**Request:**
```http
GET http://localhost:3000/api/exercises
```

**Optional Filters:**
```http
GET http://localhost:3000/api/exercises?category=cardio
GET http://localhost:3000/api/exercises?search=push
GET http://localhost:3000/api/exercises?category=strength&search=bench
```

**Response:**
```json
[
  {
    "id": 1,
    "name": "Push-ups",
    "category": "strength",
    "muscleGroup": "Chest",
    "equipment": "None",
    "difficulty": "Beginner",
    "sets": 3,
    "reps": "12",
    "caloriesPerMin": 7
  },
  {
    "id": 2,
    "name": "Bench Press",
    "category": "strength",
    "muscleGroup": "Chest",
    "equipment": "Barbell",
    "difficulty": "Intermediate",
    "sets": 4,
    "reps": "8-10",
    "caloriesPerMin": 8
  }
]
```

### 11. Get Workout Plans

**Request:**
```http
GET http://localhost:3000/api/workouts/plans
```

**Response:**
```json
[
  {
    "id": 1,
    "name": "Beginner Full Body",
    "duration": 4,
    "level": "Beginner",
    "goal": "general_fitness",
    "description": "Perfect starting point for beginners",
    "exercises": [
      { "id": 1, "name": "Push-ups", ... },
      { "id": 2, "name": "Squats", ... }
    ]
  }
]
```

---

## 📈 Progress APIs

### 12. Get Progress Summary

**Request:**
```http
GET http://localhost:3000/api/progress/summary?userId=1&days=7
```

**Response:**
```json
[
  {
    "id": 1,
    "userId": 1,
    "date": "2025-03-21",
    "workoutsCompleted": 1,
    "caloriesBurned": 250,
    "minutesActive": 30,
    "weight": 75,
    "notes": null,
    "createdAt": "2025-03-21T10:00:00.000Z"
  },
  {
    "id": 2,
    "date": "2025-03-20",
    "workoutsCompleted": 0,
    "caloriesBurned": 0,
    "minutesActive": 0,
    "weight": 75.1
  }
]
```

### 13. Log Daily Progress

**Request:**
```http
POST http://localhost:3000/api/progress
Content-Type: application/json

{
  "userId": 1,
  "date": "2025-03-21",
  "workoutsCompleted": 2,
  "caloriesBurned": 450,
  "minutesActive": 60,
  "weight": 74.5,
  "notes": "Great workout day!"
}
```

**Response:**
```json
{
  "id": 8,
  "userId": 1,
  "date": "2025-03-21",
  "workoutsCompleted": 2,
  "caloriesBurned": 450,
  "minutesActive": 60,
  "weight": 74.5,
  "notes": "Great workout day!",
  "createdAt": "2025-03-21T11:50:00.000Z"
}
```

---

## 🎯 Goals APIs

### 14. Get All Goals

**Request:**
```http
GET http://localhost:3000/api/goals?userId=1
```

**Response:**
```json
[
  {
    "id": 1,
    "userId": 1,
    "title": "Run 100km this month",
    "targetValue": 100,
    "currentValue": 34,
    "unit": "km",
    "category": "cardio",
    "deadline": null,
    "completed": 0,
    "createdAt": "2025-03-01T10:00:00.000Z"
  }
]
```

### 15. Create New Goal

**Request:**
```http
POST http://localhost:3000/api/goals
Content-Type: application/json

{
  "userId": 1,
  "title": "Do 50 push-ups daily",
  "targetValue": 50,
  "currentValue": 0,
  "unit": "push-ups",
  "category": "strength",
  "deadline": "2025-04-30"
}
```

**Response:**
```json
{
  "id": 4,
  "userId": 1,
  "title": "Do 50 push-ups daily",
  "targetValue": 50,
  "currentValue": 0,
  "unit": "push-ups",
  "category": "strength",
  "deadline": "2025-04-30",
  "completed": 0,
  "createdAt": "2025-03-21T12:00:00.000Z"
}
```

### 16. Update Goal Progress

**Request:**
```http
PUT http://localhost:3000/api/goals/4
Content-Type: application/json

{
  "currentValue": 25,
  "completed": false
}
```

**Response:**
```json
{
  "id": 4,
  "userId": 1,
  "title": "Do 50 push-ups daily",
  "targetValue": 50,
  "currentValue": 25,
  "unit": "push-ups",
  "category": "strength",
  "completed": 0
}
```

### 17. Delete Goal

**Request:**
```http
DELETE http://localhost:3000/api/goals/4
```

**Response:**
```json
{
  "message": "Deleted"
}
```

---

## 🧪 Testing with cURL

### Linux/Mac Terminal:

**Register:**
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"pass123","fitnessGoal":"weight_loss"}'
```

**Login:**
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@fitpulse.app","password":"demo123"}'
```

**Get Stats:**
```bash
curl http://localhost:3000/api/users/stats?userId=1
```

---

## 🧪 Testing with JavaScript (Browser Console)

```javascript
// Register new user
fetch('http://localhost:3000/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'Browser User',
    email: 'browser@example.com',
    password: 'test123',
    fitnessGoal: 'muscle_gain'
  })
})
.then(r => r.json())
.then(console.log);

// Login
fetch('http://localhost:3000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'demo@fitpulse.app',
    password: 'demo123'
  })
})
.then(r => r.json())
.then(data => {
  console.log('Token:', data.token);
  console.log('User:', data.user);
});

// Get exercises
fetch('http://localhost:3000/api/exercises')
  .then(r => r.json())
  .then(console.log);
```

---

## 📝 Error Responses

### 400 Bad Request:
```json
{
  "error": "Missing fields",
  "message": "name, email, password, fitnessGoal required"
}
```

### 401 Unauthorized:
```json
{
  "error": "Invalid credentials",
  "message": "Email or password is incorrect"
}
```

### 404 Not Found:
```json
{
  "error": "Not found"
}
```

### 409 Conflict:
```json
{
  "error": "Email exists",
  "message": "An account with this email already exists"
}
```

### 500 Server Error:
```json
{
  "error": "Server error"
}
```

---

## 🎯 Common Testing Scenarios

### Complete User Flow:

1. **Register** → Get token & userId
2. **Get Profile** → Verify user data
3. **Update Profile** → Change name/weight
4. **Log Workout** → Create workout record
5. **Log Progress** → Daily tracking
6. **Create Goal** → Set fitness goal
7. **Update Goal** → Track progress
8. **Get Stats** → View dashboard data

---

Happy Testing! 🚀
